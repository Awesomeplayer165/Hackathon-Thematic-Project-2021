//
//  user.swift
//  Banking App
//
//  Created by Jacob Trentini on 6/5/21.
//

import Foundation


class user{
    
    var username: String = ""
    var email: String = ""
    var password: String = ""
    
    
    init(username:String, email:String, password:String){
        
        self.username = username
        self.email = email
        self.password = password
        
    }
    
}
