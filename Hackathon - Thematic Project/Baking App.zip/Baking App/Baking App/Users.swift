//
//  Users.swift
//  Banking App
//
//  Created by Jacob Trentini on 6/5/21.
//

import Foundation

class Users{
    static let shared = Users()
    
    var currentEmail = ""
    var currentUser = ""
    var currentBalance = "0"
   
}
